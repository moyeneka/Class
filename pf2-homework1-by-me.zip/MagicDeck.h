#ifndef MagicDeck_H
#define MagicDeck_H
#include "Magic.h"
#include <iostream>


const int sizeit = 100;//initializing and declaring the size of the array

class MagicDeck
{
private:
    
	Magic data[sizeit];// Array 
    int count;
	
public:
MagicDeck();
~MagicDeck();
void read_Deck();
void print_Deck();
void total_Value ();
void mostValuable();
void mostNumerous();
};
#endif

