#include "MagicDeck.h"
#include "Magic.h"
#include <fstream>
#include <string>
#include <cstdlib>


//-----------------------------------------------------------
// Constructor
//----------------------------------------------------------
MagicDeck::MagicDeck()
{
   count = 0;
}

//-----------------------------------------------------------
// Destructor
//-----------------------------------------------------------
MagicDeck::~MagicDeck()
{
   count = 0;
}

// readig from the file
void MagicDeck::read_Deck()
{
    
    // Open input file
    ifstream file;
    file.open("magic.txt");
    if (file.fail())
        cout << "Could not open magic.txt\n";

    // Read count of magic file
    string str;
    getline(file, str);
    count = atoi(str.c_str());
    // Loop reading from magic file 
    for (int i = 0; i < count && !file.eof(); i++)
    {
        getline(file, str);
        data[i].setCardName(str);
        getline(file, str);
        data[i].setManaCost(atoi(str.c_str()));
        getline(file, str);
        data[i].setType(str);
        getline(file, str);
        data[i].setCardText(str);
        getline(file, str);
        data[i].setCardNumber(atoi(str.c_str()));
        getline(file, str);
        data[i].setRarity(str);
        getline(file, str);
        data[i].setCondition(str);
        getline(file, str);
        data[i].setPurchasePrise(atof(str.c_str()));
        getline(file, str);
        data[i].setCurrentValue(atoi(str.c_str()));
        getline(file, str);
        data[i].setQuantity(atoi(str.c_str()));
        getline(file, str);
    }
    
    // Close input file
    file.close();
}

// printing from the file
void MagicDeck::print_Deck()
{
    for (int i =0; i< count; i++)
    {
    data[i].print();
    }
    
}

// calculating the total value 
void MagicDeck::total_Value ()
{
    // Declaring a variable that will be storing the the sum of total values
    float value[count];
    float value2;
    
    
    //loop that  multipling the currentvalue and the Quantity. Then storing it in an array
    for (int i =0; i< count; i++)
    {
    
        value[i] = data[i].getCurrentValue() * data[i].getQuantity();
        
    }
    // loop that is Adding all values in the array together
        for(int j = 0;j < count; ++j)
    {
       
           value2 += value[j];
    }
    
    
    cout << "Total Value =  "<< value2<<endl;
    
}

// calculating the most Valuable
void MagicDeck::mostValuable()
{   
    //Declaring a variable that will store the values of currentvalue
    float arr[count];
    
    //Declaring a variable that will store the names in the card
    string valuableName[count];
    
     for (int i =0; i< count; i++)
    {
        
        arr[i] = data[i].getCurrentValue(); 
        valuableName[i]= data[i].getCardName();
    }
 // Loop to store largest number to arr[0]
    for(int j = 0;j < count; ++j)
    {
       // Change < to > if you want to find the smallest element
       if(arr[0]<arr[j])
       {
           arr[0] = arr[j];
           valuableName[0] = valuableName[j];
       }
    }
   
   
    cout << "MostValuable Card Name is " << valuableName[0]  <<" = " << arr[0] <<endl;
    
}

// calculating the most Numerous
void MagicDeck::mostNumerous()
{
    //Declaring a variable that will store the values of currentvalue
    float record[count];
    
    //Declaring a variable that will store the names in the card
    string numerousName[count];
    
    
    // loop to store valuess into my newly created array
     for (int i =0; i< count; i++)
    {
        
        record[i] = data[i].getQuantity(); 
        numerousName[i]= data[i].getCardName();
    }
 // Loop to store largest number to record[0]
    for(int j = 1;j < count; ++j)
    {
       // Change < to > if you want to find the smallest element
       if(record[0] < record[j])
       {
           record[0] = record[j];
           numerousName[0] =numerousName[j];
    
       }
    }
   
    cout << "MostNumerous Card Name is " << numerousName[0] <<" = " << record[0] <<endl;
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    