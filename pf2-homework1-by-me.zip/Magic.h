#ifndef Magic_H
#define Magic_H

#include <string>
using namespace std;

class Magic
{
private:
    string CardName;
    int ManaCost;
    string Type;
    string CardText;
    int CardNumber ;
    string Rarity, Condition;  
    float PurchasePrise, CurrentValue, Quantity;

public:
    Magic();
    Magic(const Magic &param);
    ~Magic();
   

    string getCardName();
    int getManaCost();
    string getType();
    string getCardText();
    int getCardNumber();
    string getRarity();
    string getCondition();
    float getPurchasePrise();
    int getCurrentValue(); 
    int getQuantity();
    

    void setCardName(string Card_name);
    void setManaCost(int mana_cost);
    void setType(string type);
    void setCardText(string card_text);
    void setCardNumber(int card_number);
    void setRarity(string rarity);
    void setCondition(string condition);
    void setPurchasePrise(float purchase_prise);
    void setCurrentValue(int current_value);
    void setQuantity(int quantity);
    void print();

};
#endif

