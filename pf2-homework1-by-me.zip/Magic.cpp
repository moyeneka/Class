#include "Magic.h"
#include <iostream>
using namespace std;
/*------------------------------------------------------------------------------------------
Constructor
---------------------------------------------------------------------------------------------*/
Magic::Magic (){
  CardName = "";
  ManaCost = 0;
  Type = "";
  CardText = "";
  CardNumber = 0;
  Rarity = "";
  Condition = "";
  PurchasePrise = 0.0;
  CurrentValue = 0.0;
  Quantity = 0.0;
}

/*------------------------------------------------------------------------------------------
copy Constructor 
--------------------------------------------------------------------------------------------*/
  Magic::Magic (const Magic & param)
{
  CardName = param.CardName;
  ManaCost = param.ManaCost;
  Type = param.Type;
  CardText = param.CardText;
  CardNumber = param.CardNumber;
  Rarity = param.Rarity;
  Condition = param.Condition;
  PurchasePrise = param.PurchasePrise;
  CurrentValue = param.CurrentValue;
  Quantity = param.Quantity;
}

/*------------------------------------------------------------------------------------------
Destructor
---------------------------------------------------------------------------------------------*/ 
  Magic::~Magic ()
{
}

/*------------------------------------------------------------------------------------------
All getters method
---------------------------------------------------------------------------------------------*/ 
  string Magic::getCardName ()
{
  return CardName;
}

int Magic::getManaCost ()
{
  return ManaCost;
}

string Magic::getType ()
{
  return Type;
}

string Magic::getCardText ()
{
  return CardText;
}

int Magic::getCardNumber ()
{
  return CardNumber;
}

string Magic::getRarity ()
{
  return Rarity;
}

string Magic::getCondition ()
{
  return Condition;
}

float Magic::getPurchasePrise ()
{
  return PurchasePrise;
}

int Magic::getCurrentValue ()
{
  return CurrentValue;
}

int Magic::getQuantity ()
{
  return Quantity;
}

/*------------------------------------------------------------------------------------------
All Setters method
---------------------------------------------------------------------------------------------*/
void Magic::setCardName (string card_name)
{
  CardName = card_name;
}

void
Magic::setManaCost (int mana_cost)
{
  ManaCost = mana_cost;
}

void
Magic::setType (string type)
{
  Type = type;
}

void
Magic::setCardText (string card_text)
{
  CardText = card_text;
}

void
Magic::setCardNumber (int card_number)
{
  CardNumber = card_number;
}

void
Magic::setRarity (string rarity)
{
  Rarity = rarity;
}

void
Magic::setCondition (string condition)
{
  Condition = condition;
}

void
Magic::setPurchasePrise (float purchase_prise)
{
  PurchasePrise = purchase_prise;
}

void
Magic::setCurrentValue (int current_value)
{
  CurrentValue = current_value;
}

void
Magic::setQuantity (int quantity)
{
  Quantity = quantity;
}
/*------------------------------------------------------------------------------------------
Print method
--------------------------------------------------------------------------------------------*/
void Magic::print ()
{
  cout << "CardName: " << CardName << endl
    << "ManaCost: " << ManaCost << endl
    << "Type: " << Type << endl
    << "CardText: " << CardText << endl
    << "CardNumber: " << CardNumber << endl
    << "Rarity: " << Rarity << endl
    << "Condition: " << Condition << endl
    << "PurchasePrise: " << PurchasePrise << endl
    << "CurrentValue: " << CurrentValue << endl
    << "Quanlity: " << Quantity << endl << endl;
}
